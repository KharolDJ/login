const welcomeScreen = document.getElementById("welcome-screen");

// Solo ocultar la ventana cuando se haga clic en cualquier parte de ella
if (welcomeScreen) { // Asegúrate de que el elemento existe
    welcomeScreen.addEventListener("click", () => {
        welcomeScreen.classList.add("hidden");
    });
}
const container= document.querySelector(".container");

const btnSignIn= document.getElementById("btn-sign-in");
const btnSignUp= document.getElementById("btn-sign-up");

btnSignIn.addEventListener("click",()=>{
    container.classList.remove("toggle");

});
btnSignUp.addEventListener("click",()=>{
    container.classList.add("toggle");


});